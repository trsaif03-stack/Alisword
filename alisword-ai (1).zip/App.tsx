
import React, { useState, useEffect, useRef } from 'react';
import Sidebar from './components/Sidebar';
import ChatArea from './components/ChatArea';
import InputSection from './components/InputSection';
import LiveSession from './components/LiveSession';
import { ChatSession, Message, MessageRole, ModelType } from './types';
import { GoogleGenAI } from "@google/genai";

const App: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [selectedModel, setSelectedModel] = useState<ModelType>(ModelType.FLASH);
  
  // Initialize first session if none exists
  useEffect(() => {
    if (sessions.length === 0) {
      const newId = Date.now().toString();
      const initialSession: ChatSession = {
        id: newId,
        title: 'New Chat',
        messages: [],
        createdAt: Date.now()
      };
      setSessions([initialSession]);
      setActiveSessionId(newId);
    }
  }, [sessions.length]);

  const activeSession = sessions.find(s => s.id === activeSessionId);

  const createNewChat = () => {
    const newId = Date.now().toString();
    const newSession: ChatSession = {
      id: newId,
      title: 'New Chat',
      messages: [],
      createdAt: Date.now()
    };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newId);
  };

  const deleteSession = (id: string) => {
    setSessions(prev => prev.filter(s => s.id !== id));
    if (activeSessionId === id) {
      setActiveSessionId(sessions[0]?.id || null);
    }
  };

  const updateSessionMessages = (sessionId: string, messages: Message[]) => {
    setSessions(prev => prev.map(s => {
      if (s.id === sessionId) {
        // Auto-update title based on first message
        const title = messages.length > 0 ? messages[0].content.substring(0, 30) + '...' : 'New Chat';
        return { ...s, messages, title };
      }
      return s;
    }));
  };

  return (
    <div className="flex h-screen w-full bg-[#0b0d11] text-gray-200 overflow-hidden">
      {/* Sidebar */}
      <Sidebar 
        sessions={sessions} 
        activeId={activeSessionId} 
        onSelect={setActiveSessionId}
        onNewChat={createNewChat}
        onDelete={deleteSession}
      />

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative h-full">
        {/* Header */}
        <header className="h-14 border-b border-gray-800 flex items-center justify-between px-6 bg-[#0b0d11]/80 backdrop-blur-md z-10">
          <div className="flex items-center space-x-3">
            <h1 className="font-bold text-xl tracking-tight text-white">Alisword <span className="text-blue-500">AI</span></h1>
            <select 
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value as ModelType)}
              className="bg-gray-800 border-none text-xs rounded-full px-3 py-1 text-gray-300 focus:ring-1 focus:ring-blue-500 outline-none"
            >
              <option value={ModelType.FLASH}>Alisword 3 Flash</option>
              <option value={ModelType.PRO}>Alisword 3 Pro</option>
            </select>
          </div>
          <button 
            onClick={() => setIsLiveActive(true)}
            className="flex items-center space-x-2 bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 px-4 py-1.5 rounded-full text-sm font-medium transition-all"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
            </span>
            <span>Live Voice</span>
          </button>
        </header>

        {/* Chat Body */}
        <ChatArea 
          messages={activeSession?.messages || []} 
          isLiveActive={isLiveActive}
        />

        {/* Input area */}
        <InputSection 
          onSend={(msg) => {
            if (activeSessionId) {
              const currentMessages = activeSession?.messages || [];
              updateSessionMessages(activeSessionId, [...currentMessages, msg]);
            }
          }}
          onResponse={(responseMsg) => {
             if (activeSessionId) {
              const currentMessages = sessions.find(s => s.id === activeSessionId)?.messages || [];
              updateSessionMessages(activeSessionId, [...currentMessages, responseMsg]);
            }
          }}
          selectedModel={selectedModel}
        />
        
        {/* Modals */}
        {isLiveActive && (
          <LiveSession onClose={() => setIsLiveActive(false)} />
        )}
      </main>
    </div>
  );
};

export default App;
