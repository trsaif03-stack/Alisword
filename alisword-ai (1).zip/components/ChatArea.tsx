
import React, { useRef, useEffect } from 'react';
import { Message, MessageRole } from '../types';

interface ChatAreaProps {
  messages: Message[];
  isLiveActive: boolean;
}

const ChatArea: React.FC<ChatAreaProps> = ({ messages, isLiveActive }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  if (messages.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-center px-6">
        <div className="w-20 h-20 bg-gradient-to-tr from-blue-600 to-cyan-400 rounded-3xl flex items-center justify-center mb-6 shadow-2xl shadow-blue-500/20">
          <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        </div>
        <h2 className="text-3xl font-bold mb-2 text-white">I'm Alisword AI</h2>
        <p className="text-gray-400 max-w-md">Your advanced workspace companion for creation, research, and high-fidelity video generation.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-10 max-w-2xl w-full">
            <div className="p-4 bg-gray-800/30 border border-gray-700/50 rounded-2xl text-left hover:border-blue-500/50 transition-all cursor-pointer">
                <p className="text-sm font-semibold text-blue-400 mb-1">Creative</p>
                <p className="text-xs text-gray-400">"Generate a high-res cyberpunk landscape 16:9"</p>
            </div>
             <div className="p-4 bg-gray-800/30 border border-gray-700/50 rounded-2xl text-left hover:border-blue-500/50 transition-all cursor-pointer">
                <p className="text-sm font-semibold text-blue-400 mb-1">Research</p>
                <p className="text-xs text-gray-400">"Latest news on space travel from Google Search"</p>
            </div>
        </div>
      </div>
    );
  }

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 md:px-10 py-6 space-y-8">
      {messages.map((msg) => (
        <div 
          key={msg.id} 
          className={`flex ${msg.role === MessageRole.USER ? 'justify-end' : 'justify-start'}`}
        >
          <div className={`flex max-w-[85%] ${msg.role === MessageRole.USER ? 'flex-row-reverse' : 'flex-row'} items-start gap-4`}>
            <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-xs font-bold ${
              msg.role === MessageRole.USER 
                ? 'bg-gray-700 text-gray-200' 
                : 'bg-blue-600 text-white shadow-lg shadow-blue-500/20'
            }`}>
              {msg.role === MessageRole.USER ? 'U' : 'A'}
            </div>
            
            <div className={`space-y-3 ${msg.role === MessageRole.USER ? 'text-right' : 'text-left'}`}>
              <div className={`inline-block px-5 py-3 rounded-2xl leading-relaxed text-sm ${
                msg.role === MessageRole.USER 
                  ? 'bg-blue-600 text-white rounded-tr-none' 
                  : 'bg-gray-800/80 text-gray-200 rounded-tl-none border border-gray-700/50'
              }`}>
                {msg.isThinking ? (
                  <div className="flex space-x-1 py-1">
                    <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-75"></div>
                    <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-150"></div>
                  </div>
                ) : (
                  <div className="whitespace-pre-wrap">{msg.content}</div>
                )}
              </div>

              {/* Media Content */}
              {msg.image && (
                <div className="rounded-2xl overflow-hidden border border-gray-700 max-w-md shadow-2xl">
                  <img src={msg.image} alt="Generated" className="w-full h-auto" />
                </div>
              )}

              {msg.videoUrl && (
                <div className="rounded-2xl overflow-hidden border border-gray-700 max-w-md shadow-2xl">
                  <video src={msg.videoUrl} controls className="w-full h-auto" />
                </div>
              )}

              {/* Grounding Info */}
              {msg.grounding && msg.grounding.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {msg.grounding.map((chunk, idx) => (
                    <a 
                      key={idx}
                      href={chunk.web?.uri || chunk.maps?.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center space-x-2 bg-gray-800 hover:bg-gray-700 px-3 py-1.5 rounded-full text-[10px] text-blue-400 transition-colors border border-gray-700"
                    >
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                      </svg>
                      <span className="truncate max-w-[120px]">{chunk.web?.title || chunk.maps?.title || 'Source'}</span>
                    </a>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ChatArea;
