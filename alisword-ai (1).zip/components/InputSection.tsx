
import React, { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Message, MessageRole, ModelType } from '../types';

interface InputSectionProps {
  onSend: (msg: Message) => void;
  onResponse: (msg: Message) => void;
  selectedModel: ModelType;
}

const InputSection: React.FC<InputSectionProps> = ({ onSend, onResponse, selectedModel }) => {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const creatorInfo = `You are Alisword AI. Your creator and owner is T R Saif (also known as TP RR Saif). 
  About T R Saif:
  - Age: 20 years old.
  - Birth: Born on November 7, 2005, at Matrisadan Hospital, Dhalpur, Dhaka.
  - Education: Currently a student of Inter First Year. He is educated in Islamic studies and is now pursuing general education.
  - Profession: He is an Application and Web Developer.
  - Skills: He has completed courses in Digital Marketing and several other technical fields.
  If anyone asks about your owner or creator, provide these details with respect.`;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() && !selectedImage) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: MessageRole.USER,
      content: input,
      timestamp: Date.now(),
      image: selectedImage || undefined
    };

    onSend(userMsg);
    setInput('');
    setSelectedImage(null);
    setIsLoading(true);

    const thinkingMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: MessageRole.MODEL,
        content: '',
        timestamp: Date.now(),
        isThinking: true
    };
    onResponse(thinkingMsg);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const isImgGen = input.toLowerCase().includes('generate image') || input.toLowerCase().includes('create a picture');
      const isVideoGen = input.toLowerCase().includes('generate video') || input.toLowerCase().includes('create a video');

      if (isVideoGen) {
          const hasKey = await (window as any).aistudio?.hasSelectedApiKey();
          if (!hasKey) await (window as any).aistudio?.openSelectKey();

          let operation = await ai.models.generateVideos({
            model: ModelType.VIDEO,
            prompt: input,
            config: { numberOfVideos: 1, resolution: '720p', aspectRatio: '16:9' }
          });

          while (!operation.done) {
            await new Promise(resolve => setTimeout(resolve, 10000));
            operation = await ai.operations.getVideosOperation({ operation });
          }

          const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
          const videoRes = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
          const videoBlob = await videoRes.blob();
          const videoUrl = URL.createObjectURL(videoBlob);

          onResponse({
            id: Date.now().toString(),
            role: MessageRole.MODEL,
            content: 'Here is your generated video:',
            videoUrl: videoUrl,
            timestamp: Date.now()
          });
      } else if (isImgGen) {
        const response = await ai.models.generateContent({
          model: ModelType.IMAGE,
          contents: { parts: [{ text: input }] },
          config: { 
            imageConfig: { aspectRatio: "1:1" },
            systemInstruction: creatorInfo
          }
        });

        let imageUrl = '';
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        }

        onResponse({
          id: Date.now().toString(),
          role: MessageRole.MODEL,
          content: 'I created this image for you.',
          image: imageUrl,
          timestamp: Date.now()
        });
      } else {
        const groundingTools = input.toLowerCase().includes('search') ? [{ googleSearch: {} }] : [];
        if (input.toLowerCase().includes('map') || input.toLowerCase().includes('where')) {
             groundingTools.push({ googleMaps: {} } as any);
        }

        const response = await ai.models.generateContent({
          model: selectedModel,
          contents: selectedImage 
            ? { parts: [{ inlineData: { data: selectedImage.split(',')[1], mimeType: 'image/jpeg' } }, { text: input }] }
            : input,
          config: {
            tools: groundingTools.length > 0 ? groundingTools : undefined,
            systemInstruction: creatorInfo
          }
        });

        onResponse({
          id: Date.now().toString(),
          role: MessageRole.MODEL,
          content: response.text || 'Sorry, I could not generate a response.',
          grounding: response.candidates?.[0]?.groundingMetadata?.groundingChunks,
          timestamp: Date.now()
        });
      }
    } catch (error) {
      console.error(error);
      onResponse({
        id: Date.now().toString(),
        role: MessageRole.MODEL,
        content: 'There was an error processing your request.',
        timestamp: Date.now()
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="px-4 md:px-10 pb-8 pt-2 bg-gradient-to-t from-[#0b0d11] to-transparent sticky bottom-0">
      <form onSubmit={handleSubmit} className="max-w-4xl mx-auto relative group">
        {selectedImage && (
            <div className="absolute -top-24 left-0 p-2 bg-gray-800 rounded-xl border border-gray-700 flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-4">
                <img src={selectedImage} alt="Preview" className="w-16 h-16 object-cover rounded-lg" />
                <button type="button" onClick={() => setSelectedImage(null)} className="bg-red-500/20 text-red-400 p-1 rounded-full hover:bg-red-500/30">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>
        )}
        <div className="flex flex-col bg-[#1e2026] border border-gray-700/50 rounded-2xl shadow-2xl transition-all group-focus-within:border-blue-500/50 group-focus-within:ring-4 ring-blue-500/5">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSubmit(e); } }}
            placeholder="Ask Alisword anything..."
            className="w-full bg-transparent px-6 py-4 outline-none resize-none text-gray-200 placeholder-gray-500 min-h-[56px] max-h-40"
            rows={1}
          />
          <div className="flex items-center justify-between px-4 pb-3">
            <div className="flex items-center space-x-1">
              <button type="button" onClick={() => fileInputRef.current?.click()} className="p-2 hover:bg-gray-700/50 rounded-xl text-gray-400 hover:text-blue-400 transition-colors" title="Attach Image">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
              </button>
              <input type="file" ref={fileInputRef} hidden accept="image/*" onChange={handleImageUpload} />
            </div>
            <div className="flex items-center space-x-2">
                <span className="text-[10px] text-gray-500 hidden md:inline">Shift + Enter for new line</span>
                <button disabled={isLoading || (!input.trim() && !selectedImage)} className={`p-2.5 rounded-xl flex items-center justify-center transition-all ${isLoading || (!input.trim() && !selectedImage) ? 'bg-gray-700 text-gray-500 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-500/20'}`}>
                    {isLoading ? <svg className="animate-spin w-5 h-5" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg> : <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 5l7 7-7 7M5 5l7 7-7 7" /></svg>}
                </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default InputSection;
