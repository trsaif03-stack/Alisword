
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';

interface LiveSessionProps {
  onClose: () => void;
}

// Helper functions as per Gemini Live API guidelines
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const LiveSession: React.FC<LiveSessionProps> = ({ onClose }) => {
  const [isConnecting, setIsConnecting] = useState(true);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [status, setStatus] = useState('Connecting to Alisword Network...');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  useEffect(() => {
    let active = true;
    const apiKey = process.env.API_KEY;
    
    if (!apiKey) {
      setStatus('API Key missing. Please check configuration.');
      setIsConnecting(false);
      return;
    }

    const ai = new GoogleGenAI({ apiKey });

    const setupAudio = async () => {
      try {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        const systemInstruction = `You are Alisword AI, a brilliant AI companion created by T R Saif (TP RR Saif). 
        If anyone asks about your owner or creator, you must tell them:
        "My creator and owner is T R Saif. He is 20 years old, born on November 7, 2005, at Matrisadan Hospital in Dhalpur, Dhaka. 
        He is currently an Inter First Year student. He has a strong background in Islamic studies and is now studying in the general line. 
        Saif is a highly skilled Application and Web Developer, and he has successfully completed courses in Digital Marketing and various other technical fields."
        Keep your tone friendly, conversational, and respectful.`;

        const sessionPromise = ai.live.connect({
          model: 'gemini-2.5-flash-native-audio-preview-12-2025',
          callbacks: {
            onopen: () => {
              if (!active) return;
              setIsConnecting(false);
              setStatus('Alisword is listening...');
              const source = audioContextRef.current!.createMediaStreamSource(stream);
              const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
              scriptProcessor.onaudioprocess = (e) => {
                if (!active) return;
                const inputData = e.inputBuffer.getChannelData(0);
                const l = inputData.length;
                const int16 = new Int16Array(l);
                for (let i = 0; i < l; i++) { int16[i] = inputData[i] * 32768; }
                const pcmBlob = {
                  data: encode(new Uint8Array(int16.buffer)),
                  mimeType: 'audio/pcm;rate=16000',
                };
                sessionPromise.then(session => { if (active) session.sendRealtimeInput({ media: pcmBlob }); });
              };
              source.connect(scriptProcessor);
              scriptProcessor.connect(audioContextRef.current!.destination);
            },
            onmessage: async (message: LiveServerMessage) => {
               if (!active) return;
               if (message.serverContent?.outputTranscription) {
                  setTranscription(prev => prev + ' ' + message.serverContent?.outputTranscription?.text);
               }
               const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
               if (base64Audio && outputAudioContextRef.current) {
                  setIsSpeaking(true);
                  const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContextRef.current, 24000, 1);
                  const source = outputAudioContextRef.current.createBufferSource();
                  source.buffer = audioBuffer;
                  source.connect(outputAudioContextRef.current.destination);
                  nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContextRef.current.currentTime);
                  source.start(nextStartTimeRef.current);
                  nextStartTimeRef.current += audioBuffer.duration;
                  source.onended = () => {
                      sourcesRef.current.delete(source);
                      if (sourcesRef.current.size === 0) setIsSpeaking(false);
                  };
                  sourcesRef.current.add(source);
               }
               if (message.serverContent?.interrupted) {
                  sourcesRef.current.forEach(s => { try { s.stop(); } catch(e) {} });
                  sourcesRef.current.clear();
                  nextStartTimeRef.current = 0;
                  setIsSpeaking(false);
               }
            },
            onerror: (e) => { console.error('Live Error:', e); setStatus('Connection error. Please try again.'); },
            onclose: () => { console.log('Live session closed'); if (active) setStatus('Connection closed.'); },
          },
          config: {
            responseModalities: [Modality.AUDIO],
            outputAudioTranscription: {},
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
            systemInstruction: systemInstruction
          }
        });
        sessionRef.current = await sessionPromise;
      } catch (err) {
        console.error('Setup Error:', err);
        setStatus('Failed to access microphone or connect.');
        setIsConnecting(false);
      }
    };

    setupAudio();
    return () => {
      active = false;
      if (sessionRef.current) { try { sessionRef.current.close(); } catch(e) {} }
      audioContextRef.current?.close();
      outputAudioContextRef.current?.close();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 bg-[#0b0d11]/95 backdrop-blur-xl flex flex-col items-center justify-center p-6 transition-all animate-in fade-in">
      <button onClick={onClose} className="absolute top-6 right-6 p-3 bg-gray-800 hover:bg-gray-700 rounded-full text-gray-300 transition-colors">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
      </button>
      <div className="relative flex flex-col items-center max-w-2xl w-full text-center">
        <div className="relative mb-12">
            <div className={`absolute inset-0 rounded-full blur-2xl transition-all duration-1000 ${isSpeaking ? 'bg-blue-500/40 scale-150' : 'bg-blue-500/20 scale-100'}`}></div>
            <div className={`w-40 h-40 rounded-full border-2 border-blue-500/30 flex items-center justify-center transition-transform duration-500 ${isSpeaking ? 'scale-110' : 'scale-100'}`}>
                <div className={`w-32 h-32 rounded-full border-4 border-blue-500/50 flex items-center justify-center transition-all ${isSpeaking ? 'animate-pulse' : ''}`}>
                    <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center shadow-xl">
                        <svg className={`w-12 h-12 text-white transition-transform ${isSpeaking ? 'scale-125' : 'scale-100'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                        </svg>
                    </div>
                </div>
            </div>
        </div>
        <h3 className="text-2xl font-bold mb-2 text-white tracking-tight">{isConnecting ? 'Initializing...' : 'Alisword Live'}</h3>
        <p className={`text-sm mb-8 transition-colors ${isSpeaking ? 'text-blue-400' : 'text-gray-400'}`}>{status}</p>
        <div className="w-full bg-gray-800/40 border border-gray-700/50 rounded-2xl p-6 min-h-[120px] max-h-[200px] overflow-y-auto text-left shadow-2xl">
            {transcription ? <p className="text-gray-300 leading-relaxed italic">"{transcription.trim()}"</p> : (
                <div className="flex flex-col items-center justify-center h-full text-gray-600 space-y-2">
                    <p className="text-xs uppercase tracking-widest font-bold">Live Transcript</p>
                    <p className="text-xs">Speak naturally to interact...</p>
                </div>
            )}
        </div>
        <div className="mt-12 flex space-x-4">
             <div className="flex items-center space-x-2 bg-gray-800/80 px-4 py-2 rounded-full border border-gray-700">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">High Fidelity Audio</span>
             </div>
        </div>
      </div>
    </div>
  );
};

export default LiveSession;
