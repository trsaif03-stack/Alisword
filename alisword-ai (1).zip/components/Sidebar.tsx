
import React from 'react';
import { ChatSession } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNewChat: () => void;
  onDelete: (id: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ sessions, activeId, onSelect, onNewChat, onDelete }) => {
  return (
    <aside className="w-64 bg-[#13151a] flex flex-col border-r border-gray-800 transition-all duration-300 ease-in-out md:translate-x-0 -translate-x-full absolute md:relative z-20 h-full">
      <div className="p-4">
        <button 
          onClick={onNewChat}
          className="w-full flex items-center justify-start space-x-3 px-4 py-3 bg-gray-800/50 hover:bg-gray-700/50 rounded-xl transition-colors text-sm font-medium text-gray-200 border border-gray-700/50"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          <span>New Chat</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-3 space-y-1">
        <p className="px-4 py-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest">Recent Chats</p>
        {sessions.map((session) => (
          <div 
            key={session.id}
            className={`group relative flex items-center rounded-lg px-3 py-2.5 transition-all cursor-pointer ${
              activeId === session.id 
                ? 'bg-blue-600/10 text-blue-400' 
                : 'text-gray-400 hover:bg-gray-800/50 hover:text-gray-200'
            }`}
            onClick={() => onSelect(session.id)}
          >
            <svg className="w-4 h-4 mr-3 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
            </svg>
            <span className="truncate text-xs font-medium max-w-[140px]">{session.title}</span>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onDelete(session.id);
              }}
              className="absolute right-2 opacity-0 group-hover:opacity-100 p-1 hover:bg-red-500/20 hover:text-red-400 rounded transition-all"
            >
              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-gray-800 space-y-2">
        <div className="flex items-center space-x-3 px-3 py-2 rounded-lg hover:bg-gray-800 transition-colors cursor-pointer">
          <img src="https://picsum.photos/32/32" className="w-8 h-8 rounded-full border border-gray-700" alt="Avatar" />
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-medium truncate">Guest User</p>
            <p className="text-[10px] text-gray-500 truncate">Free Plan</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
